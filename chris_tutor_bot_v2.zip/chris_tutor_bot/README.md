# 📚 Chris Tutor Bot

A modular Discord bot + Flask API that runs 7th grade TEKS-aligned quizzes AND handles free-form homework help — all powered by a local Ollama AI.

---

## 🏗️ Architecture

```
Discord (front-end)
      ↓
  bot.py + cogs/
      ↓
  tutor.py  ←→  Ollama (local AI)
      ↑
  api.py (Flask — optional, for future web/mobile clients)
      ↑
  progress.py + questions.py (data layer)
```

---

## 📁 File Structure

```
chris_tutor_bot/
├── bot.py              ← Discord bot entry point (run this)
├── api.py              ← Flask API server (optional, run separately)
├── tutor.py            ← AI engine — calls Ollama HTTP API
├── questions.py        ← TEKS question bank (add questions here)
├── progress.py         ← Per-user skill tracking
├── requirements.txt
├── .env.example        ← Copy to .env and fill in
├── data/
│   └── progress.json   ← Auto-created, stores all user progress
└── cogs/
    ├── quiz.py         ← !quiz, !drill, !question, !quit
    ├── homework.py     ← !ask, !solve  ← NEW
    ├── progress.py     ← !progress, !xp, !weakskills
    └── help_cmd.py     ← !help
```

---

## ⚡ Setup (One Time)

### 1. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 2. Install & start Ollama
```bash
# Install from https://ollama.com
ollama pull llama3
ollama serve
```

### 3. Create your Discord bot
1. Go to https://discord.com/developers/applications
2. Click **New Application** → name it "Chris Tutor"
3. Go to **Bot** → click **Add Bot**
4. Copy the **Token**
5. Go to **OAuth2 → URL Generator**
   - Scopes: `bot`
   - Permissions: `Send Messages`, `Read Messages`, `Embed Links`
6. Open the generated URL and add the bot to your server

### 4. Configure environment
```bash
cp .env.example .env
# Edit .env and paste your Discord token
```

### 5. Run the bot
```bash
python bot.py
```

### 6. (Optional) Run the Flask API separately
```bash
python api.py
# Runs on http://localhost:5000
```

---

## 💬 Commands

| Command | What it does |
|---|---|
| `!quiz` | Full session with all TEKS questions |
| `!question` | One random question |
| `!drill <skill>` | Practice a specific skill |
| `!drill` | List all drillable skills |
| `!quit` | End current session |
| `!ask <q> \| <answer>` | **Free-form homework help — paste any problem** |
| `!ask <q> \| <answer> \| <correct>` | Same with correct answer provided |
| `!solve <problem>` | AI solves and explains any problem |
| `!progress` | See skill-by-skill breakdown |
| `!xp` | See level, XP, and streak |
| `!weakskills` | See what needs the most work |
| `!help` | Show all commands |

---

## 📚 The !ask Command (for parents)

This is the key command for homework help. Parents paste any problem directly:

```
!ask 3/4 + 1/2 | 4/6
!ask What is 25% of 80? | 15 | 20
!ask Solve 2x + 3 = 11 | x = 3
```

The AI will:
1. Check if the answer is right or wrong
2. Explain why step by step
3. Show the correct solution

---

## 🌐 Flask API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Check if server is running |
| POST | `/ask` | Free-form homework help |
| POST | `/explain` | Structured quiz explanation |

Example API call:
```bash
curl -X POST http://localhost:5000/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "3/4 + 1/2", "user_answer": "4/6"}'
```

---

## ➕ Adding New Questions

Open `questions.py` and add to the `QUESTIONS` list:

```python
{
    "skill": "Your Skill Name",
    "question": "What is 5²?",
    "answer": "25",
    "hint": "Multiply 5 × 5."
},
```

---

## 🔧 Swapping the AI Model

In `.env`:
```
OLLAMA_MODEL=mistral
```
Pull it first: `ollama pull mistral`
